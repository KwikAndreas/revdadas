"use client";

import type { Meta, DashboardFilters } from "@/lib/types";

interface SidebarProps {
  meta: Meta;
  filters: DashboardFilters;
  onFilterChange: (partial: Partial<DashboardFilters>) => void;
}

export default function Sidebar({ meta, filters, onFilterChange }: SidebarProps) {
  const allTaxTypes = ["Semua Pendapatan", ...meta.tax_types];

  const handleProvinceToggle = (province: string) => {
    const current = filters.selectedProvinces;
    const updated = current.includes(province)
      ? current.filter((p) => p !== province)
      : [...current, province];
    onFilterChange({ selectedProvinces: updated.length > 0 ? updated : meta.provinces });
  };

  return (
    <aside className="sidebar">
      {/* Logo */}
      <div className="sidebar-logo">
        <div className="sidebar-logo-icon">א</div>
        <div className="sidebar-logo-text">
          <h2>RevDadas</h2>
          <span>REVENUE DAERAH CERDAS</span>
        </div>
      </div>

      {/* Tax Type Filter */}
      <div>
        <p className="sidebar-section-title">JENIS PENDAPATAN</p>
        <select
          className="select-input"
          value={filters.selectedTaxType}
          onChange={(e) => onFilterChange({ selectedTaxType: e.target.value })}
        >
          {allTaxTypes.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      {/* Province Filter */}
      <div>
        <p className="sidebar-section-title">PROVINSI TARGET</p>
        <div className="checkbox-group">
          {meta.provinces.map((prov) => (
            <label key={prov} className="checkbox-label">
              <input
                type="checkbox"
                checked={filters.selectedProvinces.includes(prov)}
                onChange={() => handleProvinceToggle(prov)}
              />
              {prov}
            </label>
          ))}
        </div>
      </div>

      {/* Forecast Period Slider */}
      <div className="slider-container">
        <div className="slider-header">
          <span className="sidebar-section-title" style={{ margin: 0 }}>
            PERIODE PREDIKSI
          </span>
          <span className="slider-value">{filters.forecastMonths} BULAN</span>
        </div>
        <input
          type="range"
          className="slider-input"
          min={6}
          max={24}
          value={filters.forecastMonths}
          onChange={(e) =>
            onFilterChange({ forecastMonths: Number(e.target.value) })
          }
        />
        <div className="slider-range-labels">
          <span>6 Bln</span>
          <span>24 Bln</span>
        </div>
      </div>

      {/* Fraud Prevention Slider */}
      <div>
        <div className="fraud-box">
          <div className="fraud-header">
            <span>PENCEGAHAN FRAUD</span>
            <span>{filters.fraudPreventionPct}%</span>
          </div>
          <input
            type="range"
            className="slider-input"
            min={1}
            max={100}
            value={filters.fraudPreventionPct}
            onChange={(e) =>
              onFilterChange({ fraudPreventionPct: Number(e.target.value) })
            }
          />
        </div>
        <p className="fraud-note">*Estimasi efektivitas audit AI</p>
      </div>

      {/* Status */}
      <div className="sidebar-status">
        <p>
          Status Sistem: <span className="status-dot">●</span> Terkoneksi (Satu Data)
        </p>
        <p>Data: {meta.total_rows.toLocaleString()} records</p>
      </div>
    </aside>
  );
}
