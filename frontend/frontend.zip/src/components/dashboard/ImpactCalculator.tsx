import { formatCurrency } from "@/lib/utils";

interface ImpactCalculatorProps {
  potentialLoss: number;
  fraudPreventionPct: number;
  onShowRecs: () => void;
}

export default function ImpactCalculator({
  potentialLoss,
  fraudPreventionPct,
  onShowRecs,
}: ImpactCalculatorProps) {
  const potensiTambahan = potentialLoss * (fraudPreventionPct / 100);

  return (
    <div>
      <div className="impact-card">
        <div className="impact-header">
          <span>🧮</span> Impact Calculator
        </div>
        <div className="impact-label">POTENSI TAMBAHAN KAS</div>
        <div className="impact-value">{formatCurrency(potensiTambahan)}</div>
        <div className="impact-quote">
          "Dengan menekan fraud sebesar <b>{fraudPreventionPct}%</b>, wilayah
          ini dapat mendanai pembangunan infrastruktur dan fasilitas publik
          baru."
        </div>
      </div>

      <div style={{ marginTop: "-10px", position: "relative", zIndex: 5 }}>
        <button className="btn-green" onClick={onShowRecs}>
          ✨ Rekomendasi Kebijakan
        </button>
      </div>
    </div>
  );
}
