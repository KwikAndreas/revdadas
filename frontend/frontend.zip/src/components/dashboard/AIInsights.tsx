export default function AIInsights({ insightText }: { insightText: string }) {
  return (
    <div className="insight-card">
      <div className="insight-header">
        <span style={{ color: "#eab308" }}>⚡</span> AI Insights
      </div>
      <div className="warning-box">
        <div className="warning-icon">!</div>
        <div>
          <div className="warning-label">PERINGATAN ANOMALI</div>
          <div
            className="warning-text"
            dangerouslySetInnerHTML={{ __html: insightText }}
          />
        </div>
      </div>
    </div>
  );
}
