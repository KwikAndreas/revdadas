import { useState } from "react";
import type {
  ForecastRecord,
  AnomalyRecord,
  AccuracyData,
  BusinessData,
  HistoricalRecord,
} from "@/lib/types";
import { formatCurrency, getLabelColor } from "@/lib/utils";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface DataTabsProps {
  forecast: ForecastRecord[];
  anomalies: AnomalyRecord[];
  accuracy: AccuracyData;
  business: BusinessData;
  historical: HistoricalRecord[];
  selectedProvinces: string[];
  forecastMonths: number;
}

export default function DataTabs({
  forecast,
  anomalies,
  accuracy,
  business,
  historical,
  selectedProvinces,
  forecastMonths,
}: DataTabsProps) {
  const [activeTab, setActiveTab] = useState(0);

  const tabs = [
    "📈 Forecast Data",
    "🚨 Anomalies",
    "🎯 Akurasi Model",
    "💼 Rekomendasi Bisnis",
    "🎚️ Simulasi What-If",
    "📚 Metodologi",
  ];

  return (
    <div className="tabs-container animate-fade-in-up">
      <div className="tabs-header">
        {tabs.map((tab, i) => (
          <button
            key={i}
            className={`tab-button ${activeTab === i ? "tab-button--active" : ""}`}
            onClick={() => setActiveTab(i)}
          >
            {tab}
          </button>
        ))}
      </div>
      <div className="tab-content">
        {activeTab === 0 && <TabForecast forecast={forecast} />}
        {activeTab === 1 && <TabAnomalies anomalies={anomalies} />}
        {activeTab === 2 && <TabAccuracy accuracy={accuracy} />}
        {activeTab === 3 && (
          <TabBusiness
            business={business}
            selectedProvinces={selectedProvinces}
          />
        )}
        {activeTab === 4 && (
          <TabWhatIf forecast={forecast} historical={historical} />
        )}
        {activeTab === 5 && <TabMethodology />}
      </div>
    </div>
  );
}

// ─── Tab 1: Forecast ──────────────────────────────────────────
function TabForecast({ forecast }: { forecast: ForecastRecord[] }) {
  if (!forecast || forecast.length === 0) {
    return <div className="empty-state">Data forecast tidak tersedia.</div>;
  }

  const downloadCSV = () => {
    const headers = ["Tanggal,Provinsi,Jenis_Pendapatan,Prediksi,Batas_Bawah,Batas_Atas,Metode"];
    const rows = forecast.map(r => 
      `${r.Tanggal.split("T")[0]},"${r.Provinsi}","${r.Jenis_Pendapatan}",${r.Prediksi},${r.Batas_Bawah},${r.Batas_Atas},"${r.Metode || ''}"`
    );
    const csvContent = "data:text/csv;charset=utf-8," + headers.concat(rows).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "revdadas_proyeksi.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
        <p className="table-caption" style={{ margin: 0 }}>Menampilkan {forecast.length} baris data proyeksi.</p>
        <button className="btn btn-secondary" onClick={downloadCSV}>⬇️ Unduh CSV</button>
      </div>
      <div className="data-table-wrapper" style={{ maxHeight: 400 }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Provinsi</th>
              <th>Jenis Pendapatan</th>
              <th>Prediksi</th>
              <th>Batas Bawah</th>
              <th>Batas Atas</th>
              <th>Metode</th>
            </tr>
          </thead>
          <tbody>
            {forecast.slice(0, 100).map((r, i) => (
              <tr key={i}>
                <td>{r.Tanggal.split("T")[0]}</td>
                <td>{r.Provinsi}</td>
                <td>{r.Jenis_Pendapatan}</td>
                <td style={{ fontWeight: 600, color: "#1e3a5f" }}>{formatCurrency(r.Prediksi)}</td>
                <td>{formatCurrency(r.Batas_Bawah)}</td>
                <td>{formatCurrency(r.Batas_Atas)}</td>
                <td>{r.Metode || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {forecast.length > 100 && (
        <p className="table-caption" style={{ textAlign: "center" }}>Hanya menampilkan 100 baris pertama. Unduh CSV untuk melihat semua data.</p>
      )}
    </div>
  );
}

// ─── Tab 2: Anomalies ─────────────────────────────────────────
function TabAnomalies({ anomalies }: { anomalies: AnomalyRecord[] }) {
  const anomaliesOnly = anomalies
    .filter((a) => a.Anomaly)
    .sort((a, b) => (b.Anomaly_Score || 0) - (a.Anomaly_Score || 0));

  if (anomaliesOnly.length === 0) {
    return <div className="success-box">✅ Tidak ada anomali terdeteksi pada data yang dipilih.</div>;
  }

  return (
    <div>
      <div className="data-table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Provinsi</th>
              <th>Jenis Pendapatan</th>
              <th>Realisasi</th>
              <th>Severity</th>
              <th>Alasan</th>
            </tr>
          </thead>
          <tbody>
            {anomaliesOnly.map((r, i) => (
              <tr key={i}>
                <td>{r.Tanggal.split("T")[0]}</td>
                <td>{r.Provinsi}</td>
                <td>{r.Jenis_Pendapatan}</td>
                <td style={{ color: "#dc2626", fontWeight: 600 }}>{formatCurrency(r.Realisasi)}</td>
                <td>
                  <span style={{ 
                    padding: "2px 8px", 
                    borderRadius: 12, 
                    fontSize: 11,
                    background: r.Severity === "Tinggi" ? "#fee2e2" : "#fef3c7",
                    color: r.Severity === "Tinggi" ? "#991b1b" : "#92400e"
                  }}>
                    {r.Severity}
                  </span>
                </td>
                <td style={{ fontSize: 11, maxWidth: 300 }}>{r.Alasan}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Tab 3: Accuracy ──────────────────────────────────────────
function TabAccuracy({ accuracy }: { accuracy: AccuracyData }) {
  if (!accuracy || !accuracy.overall) {
    return <div className="empty-state">Data akurasi belum tersedia.</div>;
  }

  return (
    <div>
      <div className="metrics-row">
        <div className="metric-card">
          <div className="metric-label">Akurasi Model (Median)</div>
          <div className="metric-value">{accuracy.overall.akurasi.toFixed(0)}%</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Seri Andal (WAPE &lt; 50%)</div>
          <div className="metric-value">{accuracy.overall.n_reliable} / {accuracy.overall.n_series}</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Median WAPE</div>
          <div className="metric-value">{accuracy.overall.median_wape.toFixed(1)}%</div>
        </div>
      </div>

      <div className="data-table-wrapper" style={{ maxHeight: 300 }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Provinsi</th>
              <th>Jenis Pendapatan</th>
              <th>Akurasi</th>
              <th>WAPE</th>
              <th>sMAPE</th>
              <th>Keandalan</th>
            </tr>
          </thead>
          <tbody>
            {accuracy.by_series.map((r, i) => {
              const w = r.WAPE;
              let keandalan = "🔴 Lemah";
              let color = "#ef4444";
              if (w !== null) {
                if (w < 30) { keandalan = "🟢 Andal"; color = "#10b981"; }
                else if (w < 50) { keandalan = "🟡 Cukup"; color = "#f59e0b"; }
              }

              return (
                <tr key={i}>
                  <td>{r.Provinsi}</td>
                  <td>{r.Jenis_Pendapatan}</td>
                  <td>{r.Akurasi.toFixed(1)}%</td>
                  <td>{r.WAPE !== null ? r.WAPE.toFixed(1) + "%" : "-"}</td>
                  <td>{r.sMAPE !== null ? r.sMAPE.toFixed(1) + "%" : "-"}</td>
                  <td style={{ color, fontWeight: 600 }}>{keandalan}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="table-caption">
        Akurasi & WAPE dihitung lewat backtest holdout 6 bulan terakhir. 
        WAPE = Weighted Absolute Percentage Error (semakin kecil semakin baik).
      </p>
    </div>
  );
}

// ─── Tab 4: Business ──────────────────────────────────────────
function TabBusiness({
  business,
  selectedProvinces,
}: {
  business: BusinessData;
  selectedProvinces: string[];
}) {
  if (!business || !business.scored) return null;

  const provincesToRender = selectedProvinces.filter((p) => business.scored[p]);

  if (provincesToRender.length === 0) {
    return <div className="info-box">Pilih minimal satu provinsi untuk melihat rekomendasi bisnis.</div>;
  }

  return (
    <div>
      <p style={{ fontSize: 13, color: "#475569", marginBottom: 18, lineHeight: 1.6 }}>
        Skor kelayakan <b>sektor bisnis</b> per provinsi, diturunkan dari kondisi & arah 
        kas daerah (porsi Pajak Daerah, kemandirian fiskal, skala ekonomi, tren proyeksi). 
        Skor 0&ndash;100 &mdash; semakin tinggi semakin mendukung iklim usaha sektor tersebut.
      </p>

      {provincesToRender.map((prov) => {
        const sectors = business.scored[prov];
        const topSektor = sectors[0];

        return (
          <div key={prov} className="biz-card animate-fade-in">
            <div className="biz-card-header">
              <div>
                <div className="biz-prov-label">Provinsi</div>
                <div className="biz-prov-name">{prov}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div className="biz-prov-label">Sektor Unggulan</div>
                <div className="biz-top-sektor">{topSektor.sektor}</div>
              </div>
            </div>
            
            <div className="biz-driver">
              <span style={{ fontWeight: 600, color: "#334155" }}>Pendorong: </span>
              {topSektor.alasan}
            </div>

            {sectors.map((s, i) => {
              const color = getLabelColor(s.label);
              return (
                <div key={i} className="biz-sector-row">
                  <div className="biz-sector-dot" style={{ background: color }} />
                  <div className="biz-sector-name">{s.sektor}</div>
                  <div className="biz-sector-bar">
                    <div className="biz-sector-bar-fill" style={{ width: `${s.skor}%`, background: color }} />
                  </div>
                  <div className="biz-sector-score">{s.skor}</div>
                  <div className="biz-sector-label" style={{ color }}>{s.label}</div>
                </div>
              );
            })}
          </div>
        );
      })}
      
      <p className="table-caption">
        Indikator makro tingkat provinsi dari data APBD — bukan studi kelayakan usaha. 
        Bersifat indikatif sebagai bahan pertimbangan, bukan keputusan final.
      </p>
    </div>
  );
}

// ─── Tab 5: What If ───────────────────────────────────────────
function TabWhatIf({
  forecast,
}: {
  forecast: ForecastRecord[];
  historical: HistoricalRecord[];
}) {
  const [adjustments, setAdjustments] = useState<Record<string, number>>({});

  const ADJUSTABLE = [
    { key: "Pajak Daerah", label: "Pajak Daerah" },
    { key: "Retribusi Daerah", label: "Retribusi" },
    { key: "Lain-Lain PAD yang Sah", label: "Lain-Lain PAD" },
    { key: "Pendapatan Transfer Pemerintah Pusat", label: "Transfer Pusat" },
  ];

  if (!forecast || forecast.length === 0) {
    return <div className="info-box">Proyeksi belum tersedia. Pilih provinsi di sidebar.</div>;
  }

  // Calculate Scenario
  const baseTotal = forecast.reduce((sum, r) => sum + r.Prediksi, 0);
  let scenTotal = 0;

  const scenarioData = forecast.map((r) => {
    const adjPct = adjustments[r.Jenis_Pendapatan] || 0;
    const newVal = Math.max(0, r.Prediksi * (1 + adjPct / 100));
    scenTotal += newVal;
    return { ...r, Prediksi_Skenario: newVal };
  });

  const delta = scenTotal - baseTotal;
  const deltaPct = baseTotal > 0 ? (delta / baseTotal) * 100 : 0;

  // Chart Data
  const chartDataMap = new Map<string, { date: string; base: number; scen: number }>();
  scenarioData.forEach((r) => {
    const date = r.Tanggal.split("T")[0].substring(0, 7);
    if (!chartDataMap.has(date)) {
      chartDataMap.set(date, { date, base: 0, scen: 0 });
    }
    chartDataMap.get(date)!.base += r.Prediksi / 1e9;
    chartDataMap.get(date)!.scen += r.Prediksi_Skenario / 1e9;
  });
  const chartData = Array.from(chartDataMap.values()).sort((a, b) => a.date.localeCompare(b.date));

  return (
    <div>
      <p style={{ fontSize: 13, color: "#475569", marginBottom: 14, lineHeight: 1.6 }}>
        Geser slider untuk mensimulasikan dampak <b>penyesuaian kebijakan</b> pada proyeksi pendapatan. 
        Skenario diterapkan ke periode forecast. Cocok untuk menjawab "bagaimana jika tarif Pajak Daerah naik 10%".
      </p>

      <div className="whatif-sliders">
        {ADJUSTABLE.map(({ key, label }) => {
          const val = adjustments[key] || 0;
          return (
            <div key={key}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span className="whatif-slider-label" style={{ margin: 0 }}>{label}</span>
                <span className="whatif-slider-value">{val > 0 ? `+${val}` : val}%</span>
              </div>
              <input
                type="range"
                className="slider-input"
                min="-30"
                max="30"
                value={val}
                onChange={(e) => setAdjustments({ ...adjustments, [key]: Number(e.target.value) })}
              />
            </div>
          );
        })}
      </div>

      <div className="metrics-row">
        <div className="metric-card">
          <div className="metric-label">Baseline (Total Proyeksi)</div>
          <div className="metric-value">{formatCurrency(baseTotal)}</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Skenario (Total Proyeksi)</div>
          <div className="metric-value">{formatCurrency(scenTotal)}</div>
          {delta !== 0 && (
            <div className={`metric-delta ${delta > 0 ? 'metric-delta--positive' : 'metric-delta--negative'}`}>
              {delta > 0 ? '+' : ''}{formatCurrency(delta)}
            </div>
          )}
        </div>
        <div className="metric-card">
          <div className="metric-label">Selisih Relatif</div>
          <div className="metric-value" style={{ color: delta >= 0 ? '#10b981' : '#ef4444' }}>
            {deltaPct > 0 ? '+' : ''}{deltaPct.toFixed(2)}%
          </div>
        </div>
      </div>

      <div style={{ width: "100%", height: 250, marginTop: 24 }}>
        <ResponsiveContainer>
          <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{ borderRadius: 8 }}
              formatter={(value: any) => {
              const val = typeof value === 'number' ? value : 0;
              return [`Rp ${val.toFixed(1)} M`, ""];
            }}
            />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Line type="monotone" dataKey="base" name="Baseline" stroke="#94a3b8" strokeDasharray="5 5" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="scen" name="Skenario" stroke="#1e3a5f" strokeWidth={2.5} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ─── Tab 6: Methodology ───────────────────────────────────────
function TabMethodology() {
  return (
    <div style={{ fontSize: 13, lineHeight: 1.6, color: "#334155" }}>
      <p><b>Sumber data.</b> DJPK Kementerian Keuangan — Portal SIKD (<code>djpk.kemenkeu.go.id/portal/data/apbd</code>), realisasi bulanan kumulatif 2023-2025.</p>
      
      <p><b>Model.</b> <i>Ensemble</i> Prophet + Naive-Seasonal dengan bobot adaptif per seri (dipilih lewat validasi internal). Lebih akurat & stabil dibanding Prophet murni pada deret APBD bulanan yang pendek. Prediksi dijaga <b>non-negatif</b>.</p>

      <p><b>Deteksi anomali.</b> Isolation Forest multivariat (nilai ternormalisasi, perubahan bulanan, rasio ke rata-rata bergerak, deviasi musiman) - dihitung per (Provinsi x Jenis Pendapatan) + tingkat keparahan & alasan.</p>

      <p><b>Validasi.</b> Backtest holdout 6 bulan; akurasi memakai <b>WAPE & sMAPE</b> (robust terhadap nilai kecil).</p>

      <p><b>Catatan kejujuran data.</b><br/>
      • 2021-2022 dikecualikan (SIKD hanya menyimpan angka tahunan, bukan progres bulanan).<br/>
      • 2025 kemungkinan masih <i>preliminer</i> (sebagian bulan akhir belum final).<br/>
      • Pos <i>lumpy/one-off</i> (mis. sebagian Lain-Lain PAD, Hibah) sulit diramal - keandalannya ditampilkan apa adanya pada tab Akurasi Model.</p>

      <p><b>Rekomendasi Bisnis (per sektor).</b> Skor sektor diturunkan dari sinyal fiskal ternormalisasi antar provinsi terpilih: porsi <i>Pajak Daerah</i>, <i>kemandirian fiskal</i>, <i>skala ekonomi</i>, dan <i>tren proyeksi</i>. Ini indikator MAKRO tingkat provinsi sebagai bahan pertimbangan awal, <b>bukan</b> studi kelayakan usaha.</p>
    </div>
  );
}
