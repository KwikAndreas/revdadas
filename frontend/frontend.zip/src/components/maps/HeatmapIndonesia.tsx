import { useEffect, useRef } from "react";
import L from "leaflet";
import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Popup,
  useMap,
} from "react-leaflet";
import type {
  HistoricalRecord,
  ForecastRecord,
  AnomalyRecord,
} from "@/lib/types";
import {
  PROVINCE_COORDS,
  INDONESIA_BOUNDS,
  formatCurrency,
  getRiskColor,
} from "@/lib/utils";

// Leaflet default icon fix for Next.js
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

interface HeatmapProps {
  historical: HistoricalRecord[];
  forecast: ForecastRecord[];
  anomalies: AnomalyRecord[];
  selectedProvinces: string[];
}

// Component to handle map view updates when selected provinces change
function MapUpdater({ selectedProvinces }: { selectedProvinces: string[] }) {
  const map = useMap();
  useEffect(() => {
    if (selectedProvinces.length === 0) return;
    
    // Create a bounding box covering all selected provinces
    const bounds = L.latLngBounds([]);
    selectedProvinces.forEach((prov) => {
      if (PROVINCE_COORDS[prov]) {
        bounds.extend(PROVINCE_COORDS[prov]);
      }
    });

    if (bounds.isValid()) {
      // Pad bounds slightly
      map.fitBounds(bounds.pad(0.1), { maxZoom: 8 });
    } else {
      map.fitBounds(INDONESIA_BOUNDS);
    }
  }, [map, selectedProvinces]);
  
  return null;
}

export default function HeatmapIndonesia({
  historical,
  forecast,
  anomalies,
  selectedProvinces,
}: HeatmapProps) {
  // Aggregate data per province
  const provinceData = selectedProvinces.map((prov) => {
    // Total historical revenue
    const provHistorical = historical.filter((r) => r.Provinsi === prov);
    const totalRev = provHistorical.reduce((sum, r) => sum + r.Realisasi, 0);

    // Total forecast
    const provForecast = forecast.filter((r) => r.Provinsi === prov);
    const totalForecast = provForecast.reduce((sum, r) => sum + r.Prediksi, 0);

    // Risk / Anomalies
    const provAnomalies = anomalies.filter(
      (r) => r.Provinsi === prov && r.Anomaly
    );
    const totalAnomalyValue = provAnomalies.reduce(
      (sum, r) => sum + r.Realisasi,
      0
    );
    const riskPct = totalRev > 0 ? (totalAnomalyValue / totalRev) * 100 : 0;

    return {
      provinsi: prov,
      coords: PROVINCE_COORDS[prov] || [-2.5, 118.0],
      totalRev,
      totalForecast,
      riskPct,
      color: getRiskColor(riskPct),
    };
  });

  return (
    <MapContainer
      center={[-2.5, 118.0]}
      zoom={5}
      minZoom={4}
      maxBounds={INDONESIA_BOUNDS}
      maxBoundsViscosity={1.0}
      style={{ height: 400, width: "100%", background: "#f8fafc" }}
    >
      <TileLayer
        url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
      />
      <MapUpdater selectedProvinces={selectedProvinces} />

      {provinceData.map((data) => (
        <CircleMarker
          key={data.provinsi}
          center={data.coords as [number, number]}
          radius={14}
          pathOptions={{
            color: "white",
            weight: 2,
            fillColor: data.color,
            fillOpacity: 0.9,
          }}
        >
          <Popup className="map-popup">
            <div className="map-popup-title">{data.provinsi}</div>
            <div className="map-popup-row">
              Rev Aktual:{" "}
              <span className="map-popup-value">
                {formatCurrency(data.totalRev)}
              </span>
            </div>
            <div className="map-popup-row">
              Forecast:{" "}
              <span className="map-popup-value map-popup-value--blue">
                {formatCurrency(data.totalForecast)}
              </span>
            </div>
            <div className="map-popup-row" style={{ marginBottom: 12 }}>
              Risiko Fraud:{" "}
              <span className="map-popup-value map-popup-value--red">
                {data.riskPct.toFixed(1)}%
              </span>
            </div>
            <button className="btn btn-secondary" style={{ width: "100%", padding: "6px" }}>
              Detail Wilayah
            </button>
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  );
}
